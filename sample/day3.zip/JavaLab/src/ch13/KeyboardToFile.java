package ch13;


/**
 * 표준입력장치(키보드) -> 파일(output.txt)
 * @author student
 *
 */
public class KeyboardToFile {
	public static void main(String[] args) {
		
	}
}
























